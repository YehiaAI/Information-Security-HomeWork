package com.app.phoneclient.Security;

import android.util.Base64;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 * Created by Yehia on 12/10/2016.
 */

public class PGPAlgorithm {

    private static PGPAlgorithm Instance=null;
    private static Cipher pkCipher;
    private static Cipher aesCipher;
    private static final int AES_Key_Size=256;
    private static SecretKeySpec aeskeySpec;
    private static byte[] aesKey;
    private static KeyPair keyPair;
    private static PrivateKey privateKey;
    private static PublicKey publicKey;

    public static PGPAlgorithm getInstance() throws NoSuchPaddingException, NoSuchAlgorithmException {

        if(Instance==null)
            Instance=new PGPAlgorithm();
        return Instance;
    }


    private PGPAlgorithm() throws NoSuchAlgorithmException, NoSuchPaddingException {

        GetInstanceKey();
        GetInstanceCipher();
    }

    public static PublicKey getPublicKey(){

        return publicKey;
    }

    public static PrivateKey getPrivateKey(){

        return privateKey;
    }


    private static void GetInstanceCipher() throws NoSuchPaddingException, NoSuchAlgorithmException {

        // create RSA public key cipher
        pkCipher = Cipher.getInstance("RSA");
        // create AES shared key cipher
        aesCipher = Cipher.getInstance("AES");

    }

    private void GetInstanceKey() throws NoSuchAlgorithmException {

        // Get an instance of the RSA key generator
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        // Generate the keys — might take sometime on slow computers
        this.keyPair= kpg.generateKeyPair();
        this.privateKey=keyPair.getPrivate();
        this.publicKey=keyPair.getPublic();
    }

    public static void makeSecretKey() throws NoSuchAlgorithmException {
        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(AES_Key_Size);
        SecretKey key = kgen.generateKey();
        aesKey = key.getEncoded();
        aeskeySpec = new SecretKeySpec(aesKey, "AES");
    }

    public static JSONObject Encrypt(String data) throws NoSuchAlgorithmException, BadPaddingException, IllegalBlockSizeException, JSONException, InvalidKeyException, UnsupportedEncodingException, NoSuchPaddingException {

        GetInstanceCipher();
        // to generate random key
        makeSecretKey();
        JSONObject object=new JSONObject();
        aesCipher.init(Cipher.ENCRYPT_MODE,aeskeySpec);
        byte[] dataEncryptByte=aesCipher.doFinal(data.getBytes("UTF-8"));
        object.put("data",Base64.encodeToString(dataEncryptByte,Base64.DEFAULT));
        object.put("secretKey",EncryptSecretkey());

        return object;
    }


    public static String EncryptSecretkey() throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException {

        // Initiate the Cipher, telling it that it is going to Encrypt, giving it the public key
        pkCipher.init(Cipher.ENCRYPT_MODE, publicKey);

        return Base64.encodeToString(pkCipher.doFinal(aeskeySpec.getEncoded()),Base64.DEFAULT);
    }



    public static void SetPublicKey(String publickeyEncoded) throws NoSuchAlgorithmException, InvalidKeySpecException {

        byte[] publicBytes = Base64.decode(publickeyEncoded,Base64.DEFAULT);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        publicKey = keyFactory.generatePublic(keySpec);

    }

    public static void SetSecretKey(String secretKeyEncoded) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {

        // Initiate the Cipher, telling it that it is going to Decryption, giving it the public key
        pkCipher.init(Cipher.DECRYPT_MODE, privateKey);

        aesKey=pkCipher.doFinal(Base64.decode(secretKeyEncoded,Base64.DEFAULT));
        aeskeySpec = new SecretKeySpec(aesKey, "AES");
    }

    public static String Decryption(JSONObject object) throws JSONException, NoSuchAlgorithmException, NoSuchPaddingException, BadPaddingException, InvalidKeyException, IllegalBlockSizeException {

        GetInstanceCipher();

        SetSecretKey(object.getString("secretKey"));
        aesCipher.init(Cipher.DECRYPT_MODE,aeskeySpec);

        return new String(aesCipher.doFinal(Base64.decode(object.getString("data"),Base64.DEFAULT)));
    }

}
