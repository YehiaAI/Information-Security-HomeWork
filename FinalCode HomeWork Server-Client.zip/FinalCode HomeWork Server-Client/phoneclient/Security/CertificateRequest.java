package com.app.phoneclient.Security;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;

import com.app.phoneclient.Security.DigitalSignature.GenerateDigitalSignature;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

/**
 * Created by Yehia on 12/16/2016.
 */


public class CertificateRequest {

    private static CertificateRequest Instance=null;
    private static Context context;
    private static PrivateKey privateKey;
    private static PublicKey publicKey;
    static SharedPreferences preferences;
    static SharedPreferences.Editor editor;

    public static CertificateRequest getInstance(Context mainContext) throws NoSuchAlgorithmException, InvalidKeySpecException {

        context=mainContext;
        preferences = context.getSharedPreferences("CLIENT", context.MODE_PRIVATE);
        editor = context.getSharedPreferences("CLIENT", context.MODE_PRIVATE).edit();

        if(Instance==null)
            Instance=new CertificateRequest();
        return Instance;
    }

    private CertificateRequest() throws NoSuchAlgorithmException, InvalidKeySpecException {

        if(!preferences.getBoolean("GenerateKey",false)){

            GenerateKey();
        }else
            getInstanceKey();
    }

    private void GenerateKey() throws NoSuchAlgorithmException {

        // Get an instance of the RSA key generator
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        // Generate the keys — might take sometime on slow computers
        KeyPair keyPair= kpg.generateKeyPair();
        privateKey=keyPair.getPrivate();
        publicKey=keyPair.getPublic();
        editor.putString("PublicKey", Base64.encodeToString(publicKey.getEncoded(),Base64.DEFAULT));
        editor.putString("PrivateKey",Base64.encodeToString(privateKey.getEncoded(),Base64.DEFAULT));
        editor.putBoolean("GenerateKey",true);
        editor.commit();
        Log.d("Generate Client Public",publicKey.toString());
        Log.d("Generate Client Private",privateKey.toString());
    }

    private void getInstanceKey() throws NoSuchAlgorithmException, InvalidKeySpecException {

        // get Publickey
        byte[] publicBytes = Base64.decode(preferences.getString("PublicKey",null),Base64.DEFAULT);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        publicKey = keyFactory.generatePublic(keySpec);
        Log.d("Get Client Public",publicKey.toString());

        // get PrivateKey
        byte[] privateBytes = Base64.decode(preferences.getString("PrivateKey",null),Base64.DEFAULT);
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(privateBytes);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        privateKey = factory.generatePrivate(pkcs8EncodedKeySpec);
        Log.d("Get Client Private",privateKey.toString());

    }

    /*public static void Request() throws NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException {

        // create the extension value
        GeneralNames subjectAltName = new GeneralNames(new GeneralName(GeneralName.rfc822Name, "example@example.org"));


         // create the extensions object and add it as an attribute
        Vector oids = new Vector();
        Vector values = new Vector();

        oids.add(X509Extensions.SubjectAlternativeName);
        values.add(new X509Extension(false, new DEROctetString(subjectAltName)));

        X509Extensions extensions = new X509Extensions(oids, values);
        Attribute attribute = new Attribute(
                PKCSObjectIdentifiers.pkcs_9_at_extensionRequest,
                new DERSet(extensions));

        X500Principal subjectName = new X500Principal("CN=Test V3 Certificate");

        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");        // serial number for certificate
        KeyPair keyPair =kpg.generateKeyPair();                            // EC public/private key pair



        PKCS10CertificationRequest kpGen = new PKCS10CertificationRequest("SHA512withRSA",subjectName , keyPair.getPublic(),new DERSet(attribute) ,keyPair.getPrivate());

        Log.d("RequestCA..",kpGen.getCertificationRequestInfo().getAttributes().toString());
    }*/


    public static JSONObject Make() throws NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException, JSONException {

        // SettingUp Data Info
        String clientDN=preferences.getString("CLIENTADDRESS","");

        //Creating Data
        JSONObject dataJson=new JSONObject();
        dataJson.put("client",clientDN);
        // location
        //city
        //.....

        //Making Signature
        String signature= GenerateDigitalSignature.Signing(dataJson.toString(),privateKey);

        // Creating Request..
        JSONObject requestJson=new JSONObject();
        requestJson.put("data",dataJson.toString());
        requestJson.put("signature",signature);
        requestJson.put("publicKey",Base64.encodeToString(publicKey.getEncoded(),Base64.DEFAULT));

        Log.d("Certificate Request..",requestJson.toString());

        return requestJson;
    }



}
