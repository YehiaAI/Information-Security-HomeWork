package com.app.phoneclient.Security;

import android.util.Base64;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;

/**
 * Created by Yehia on 11/27/2016.
 */

public class RSA_Assymetric {


    private static RSA_Assymetric Instance=null;
    private static PrivateKey privateKey;
    private static PublicKey publicKey;
    private static KeyPair keyPair;


    public static RSA_Assymetric getInstance() throws NoSuchAlgorithmException {

        if(Instance==null)
            Instance=new RSA_Assymetric();
        return Instance;
    }

    public static boolean IsInitialize(){

        return Instance!=null;
    }

    private RSA_Assymetric() throws NoSuchAlgorithmException {

        GetInstanceKey();
    }


    private void GetInstanceKey() throws NoSuchAlgorithmException {

        // Get an instance of the RSA key generator
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        // Generate the keys — might take sometime on slow computers
        this.keyPair= kpg.generateKeyPair();
        this.privateKey=keyPair.getPrivate();
        this.publicKey=keyPair.getPublic();
    }

    public PublicKey getPublicKey(){

        return publicKey;
    }

    public PrivateKey getPrivateKey(){

        return privateKey;
    }

    public void SetPublickey(PublicKey publicKey){
        this.publicKey=publicKey;
    }


    public SealedObject Encryption(String myMessage ) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IOException, IllegalBlockSizeException {
        // Get an instance of the Cipher for RSA encryption
        Cipher c = Cipher.getInstance("RSA");
        // Initiate the Cipher, telling it that it is going to Encrypt, giving it the public key
        c.init(Cipher.ENCRYPT_MODE, publicKey);
        Log.d("Public... ",publicKey.toString());

        // Encrypt that message using a new SealedObject and the Cipher we created before
        SealedObject myEncryptedMessage = new SealedObject(myMessage, c);
        Log.d("Encryption Object... ", myEncryptedMessage.toString());

        return  myEncryptedMessage;
    }


    public static byte[] Encryption(String myMessage,PublicKey publicKey ) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IOException, IllegalBlockSizeException {
        // Get an instance of the Cipher for RSA encryption
        Cipher c = Cipher.getInstance("RSA");
        // Initiate the Cipher, telling it that it is going to Encrypt, giving it the public key
        c.init(Cipher.ENCRYPT_MODE, publicKey);
        Log.d("Public... ",publicKey.toString());

        // Encrypt that message using a new SealedObject and the Cipher we created before
        SealedObject myEncryptedMessage = new SealedObject(myMessage, c);
        Log.d("Encryption Object... ", myEncryptedMessage.toString());

        final ByteArrayOutputStream bos = new ByteArrayOutputStream();
        final ObjectOutputStream out = new ObjectOutputStream(bos);
        out.writeObject(myEncryptedMessage);
        //final byte[] bytes = bos.toByteArray();

        return bos.toByteArray();
        //return Base64.encodeToString(bytes,Base64.DEFAULT);

    }

    public String Decryption(SealedObject myEncryptedMessage) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, ClassNotFoundException, BadPaddingException, IllegalBlockSizeException, IOException {
        // Get an instance of the Cipher for RSA decryption
        Cipher dec = Cipher.getInstance("RSA");
        // Initiate the Cipher, telling it that it is going to Decrypt, giving it the private key
        dec.init(Cipher.DECRYPT_MODE, privateKey);
        Log.d("Private...", privateKey.toString());

        // Tell the SealedObject we created before to decrypt the data and return it
        String message = (String) myEncryptedMessage.getObject(dec);
        System.out.println("Decryption.." + message);

        return message;
    }

    public static String encryptAndSerializeObject(final Serializable object, final PublicKey key) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IOException, IllegalBlockSizeException {

        if (object == null) {
            throw new IllegalArgumentException("object must not be null");
        }


            final Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            final SealedObject sealedobject = new SealedObject(object, cipher);
            final ByteArrayOutputStream bos = new ByteArrayOutputStream();
            final ObjectOutputStream out = new ObjectOutputStream(bos);
            out.writeObject(sealedobject);
            final byte[] bytes = bos.toByteArray();
            //return BaseEncoding.base64().encode(bytes);
            return Base64.encodeToString(bytes,Base64.DEFAULT);
    }


    public static SealedObject decryptAnDeserializeObject(final String string) throws IOException, ClassNotFoundException, InvalidKeyException, NoSuchAlgorithmException {

        if (string == null) {
            throw new IllegalArgumentException("string must not be null");
        }


            final byte[] userr = Base64.decode(string,Base64.DEFAULT);
            final ByteArrayInputStream bis = new ByteArrayInputStream(userr);
            final ObjectInputStream in = new ObjectInputStream(bis);
            final SealedObject ud = (SealedObject) in.readObject();
            return  ud;

    }



}
