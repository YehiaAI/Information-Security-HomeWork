package com.app.phoneclient.Security.DigitalSignature;

/**
 * Created by Yehia on 12/3/2016.
 */

import android.util.Base64;
import android.util.Log;

import java.security.*;

public class GenerateDigitalSignature {
    public static PublicKey publicKey;
    public static  byte[] digitalSignature;
    public static void main(byte[] data) {
        try {
            //
            // Get instance and initialize a KeyPairGenerator object.
            //
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
            keyGen.initialize(1024, random);
            //
            // Get a PrivateKey from the generated key pair.
            //
            KeyPair keyPair = keyGen.generateKeyPair();
            PrivateKey privateKey = keyPair.getPrivate();

            publicKey=keyPair.getPublic();
            //
            // Get an instance of Signature object and initialize it.
            //
            Signature signature = Signature.getInstance("SHA1withRSA");
            signature.initSign(privateKey);

            //
            // Supply the data to be signed to the Signature object
            // using the update() method and generate the digital
            // signature.
            //
            //byte[] bytes = Files.readAllBytes(Paths.get("README"));
            signature.update(data);
            digitalSignature = signature.sign();

            //
            // Save digital signature and the public key to a file.
            //
            //Files.write(Paths.get("signature"), digitalSignature);
            //Files.write(Paths.get("publickey"), keyPair.getPublic().getEncoded());
            Log.d("Signature..",digitalSignature.toString());
            Log.d("Public key..",keyPair.getPublic().getEncoded().toString());

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }  catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (SignatureException e) {
            e.printStackTrace();
        }
    }

    public static String Signing(String data,PrivateKey privateKey) {
        try {
            //
            // Get instance and initialize a KeyPairGenerator object.
            //
           /* KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
            keyGen.initialize(1024, random);*/
            //
            // Get a PrivateKey from the generated key pair.
            //
           /* KeyPair keyPair = keyGen.generateKeyPair();
            PrivateKey privateKey = keyPair.getPrivate();*/

            //publicKey=keyPair.getPublic();
            //
            // Get an instance of Signature object and initialize it.
            //
            Signature signature = Signature.getInstance("SHA1withRSA");
            signature.initSign(privateKey);

            //
            // Supply the data to be signed to the Signature object
            // using the update() method and generate the digital
            // signature.
            //
            //byte[] bytes = Files.readAllBytes(Paths.get("README"));
            signature.update(Base64.decode(data,Base64.DEFAULT));
            digitalSignature = signature.sign();

            //
            // Save digital signature and the public key to a file.
            //
            //Files.write(Paths.get("signature"), digitalSignature);
            //Files.write(Paths.get("publickey"), keyPair.getPublic().getEncoded());
            Log.d("Signature..",digitalSignature.toString());
            Log.d("Private key..",privateKey.getEncoded().toString());

            return Base64.encodeToString(digitalSignature,Base64.DEFAULT);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }  catch (InvalidKeyException e) {
            e.printStackTrace();
        } catch (SignatureException e) {
            e.printStackTrace();
        }
        return  null;
    }


}