package com.app.phoneclient.Security.DigitalSignature;

/**
 * Created by Yehia on 12/3/2016.
 */

import java.security.PublicKey;
import java.security.Signature;

public class VerifyDigitalSignature {
    public static void main(byte[] digitalSignature,byte[] data,PublicKey publicKey) {
        try {
            //byte[] publicKeyEncoded = Files.readAllBytes(Paths.get("publickey"));
            //byte[] digitalSignature = Files.readAllBytes(Paths.get("signature"));

            //X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyEncoded);
            //KeyFactory keyFactory = KeyFactory.getInstance("RSA");

            //PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
            Signature signature = Signature.getInstance("SHA1withRSA");
            signature.initVerify(publicKey);

            //byte[] bytes = Files.readAllBytes(Paths.get("README"));
            signature.update(data);

            boolean verified = signature.verify(digitalSignature);
            if (verified) {
                System.out.println("Data verified.");
            } else {
                System.out.println("Cannot verify data.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
