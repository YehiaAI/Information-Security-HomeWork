package com.app.phoneclient.Activity;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.IBinder;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.app.phoneclient.R;
import com.app.phoneclient.Services.ClientConnectCall;

import org.json.JSONException;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class MainActivity extends AppCompatActivity {

    public static Button Connect, Disconnect,Request;
    TextView textView,status,name;
    public static EditText agentName,value;
    private boolean bound = false;
    ClientConnectCall clientConnectCall;
    static SharedPreferences preferences;
    public static String KEY="123456";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        preferences = this.getSharedPreferences("CLIENT", MODE_PRIVATE);

        textView=(TextView)findViewById(R.id.TextView);
        status=(TextView)findViewById(R.id.status);
        name=(TextView)findViewById(R.id.Name);


        agentName=(EditText) findViewById(R.id.AgentName);
        value=(EditText) findViewById(R.id.value);

        Connect = (Button) findViewById(R.id.ButtonConnect);
        Disconnect = (Button) findViewById(R.id.ButtonDisconnect);

        Request=(Button) findViewById(R.id.Request);


        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            startActivity(new Intent(MainActivity.this,Settings.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void ClickConnect(View v) {


        startService(new Intent(getApplicationContext(), ClientConnectCall.class));
        Connect.setEnabled(false);
        Disconnect.setEnabled(true);


    }

    public void ClickDisconnect(View v) {


        stopService(new Intent(MainActivity.this, ClientConnectCall.class));
        Connect.setEnabled(true);
        Disconnect.setEnabled(false);

    }



    public void ClickGetPublicKey(View v){

        ClientConnectCall.GetPublicKeyPGP();

    }


    public void ClickRequest(View v) throws NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException, JSONException, InvalidKeyException, IOException, BadPaddingException {

        ClientConnectCall.RequestPGP();

    }

    public void ClickRequestCeritificate(View v) throws NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, JSONException, SignatureException {

        ClientConnectCall.RequestCertificate();
    }

    private void show(String message){

        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }


    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Extract data included in the Intent
            if(intent.hasExtra("message")) {
                String message = intent.getStringExtra("message");
                //Log.d("receiver", "Got message: " + message);
                if (message.equals("Disconnected")) {
                    Connect.setEnabled(true);
                    Disconnect.setEnabled(false);
                } else
                    textView.setText(message);
            }
            else if(intent.hasExtra("status"))
            {
                String message = intent.getStringExtra("status");
                status.setText(message);
            }
        }
    };


    ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

            ClientConnectCall.LocalBinder mLocalBinder = (ClientConnectCall.LocalBinder)service;
            clientConnectCall = mLocalBinder.getServerInstance();
            bound=true;
            show("Connect..");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

            Connect.setEnabled(true);
            Disconnect.setEnabled(false);
            bound=false;
            show("Disconnect..");
            clientConnectCall=null;
        }
    };


    @Override
    protected void onResume() {
        super.onResume();

        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver,
                new IntentFilter("Data"));

        name.setText("Your Host: "+preferences.getString("CLIENTADDRESS",""));
    }


    @Override
    protected void onPause() {
        // Unregister since the activity is not visible
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Unbind from service
        if (bound) {
            // unregister
            unbindService(mConnection);
            bound = false;
        }
    }

}
