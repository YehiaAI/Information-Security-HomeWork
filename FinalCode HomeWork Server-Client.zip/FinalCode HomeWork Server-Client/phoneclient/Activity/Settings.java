package com.app.phoneclient.Activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.app.phoneclient.Fragment.SettingFragment;
import com.app.phoneclient.R;

public class Settings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        getFragmentManager()
                .beginTransaction()
                .replace(R.id.setting, new SettingFragment())
                .commit();

    }
}
