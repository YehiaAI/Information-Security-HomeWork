package com.app.phoneclient.Services;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import com.app.phoneclient.Security.CertificateRequest;
import com.app.phoneclient.Security.DigitalSignature.GenerateDigitalSignature;
import com.app.phoneclient.Security.AES;
import com.app.phoneclient.Activity.MainActivity;
import com.app.phoneclient.R;
import com.app.phoneclient.Security.PGPAlgorithm;
import com.app.phoneclient.Security.RSA_Assymetric;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/**
 * Created by Yehia on 8/4/2016.
 */
public class ClientConnectCall extends Service {

    public static ClientConnectCall Instance=null;
    static boolean  connect=false;
    private static Socket socket;
    private DataOutputStream outputStream;
    private BufferedReader inputStream;
    static ObjectInputStream objectInputStream ;
    static ObjectOutputStream objectOutputStream ;
    private static Activity activity;
    static SharedPreferences preferences;
    static SharedPreferences.Editor Editpreferences;
    private final IBinder mBinder = new LocalBinder();
    private static int Port=8888;
    private static String Clint="192.168.1.1";
    private static String ServerAddress="";
    private static ConnectServer connectServer;
    private static CheckServices checkServices;

    private static boolean status = false;

    public static void init(Activity main){
        activity=main;
    }

    public static boolean isCalling(){
        return status;
    }

    public static boolean CheckService(){

        return Instance!=null;
    }

    public class LocalBinder extends Binder {
        public ClientConnectCall getServerInstance() {
            return ClientConnectCall.this;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(R.string.app_name, new Notification());
        Instance=this;
        connectServer=new ConnectServer();
        preferences = this.getSharedPreferences("CLIENT", MODE_PRIVATE);
        Editpreferences=this.getSharedPreferences("CLIENT", MODE_PRIVATE).edit();
        Port = preferences.getInt("PORT", 8888);
        ServerAddress= preferences.getString("ADDRESS"," ");
        Clint=preferences.getString("CLIENTADDRESS","");

        // SettingUp Certificate Request..
        try {
            CertificateRequest.getInstance(getApplicationContext());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        connectServer.execute();
        return ClientConnectCall.START_STICKY;
    }


    private boolean searchNetwork() {

        try {
            socket = new Socket();
            Log.e("search",ServerAddress+" port :"+Port);
            socket.connect(new InetSocketAddress(ServerAddress,Port), 5000);
            outputStream = new DataOutputStream(socket.getOutputStream());
            inputStream = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            objectInputStream= new ObjectInputStream(socket.getInputStream());

            connect=true;
            //log("Connected");
            return true;
        } catch (Exception e) {
        }

        return false;

    }


    class ConnectServer extends AsyncTask<Void,Void,Boolean> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            ConnectingMessage();
            BuildNotification("Connecting Server..", "......");
        }

        @Override
        protected Boolean doInBackground(Void... params) {

            try {

                if (searchNetwork()) {


                    objectOutputStream= new ObjectOutputStream(outputStream);

                    return true;

                }
            } catch (IOException e) {
                //log("Error: IO Exception");
                e.printStackTrace();
            }

            return false;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            super.onPostExecute(aBoolean);

            if(objectInputStream!=null) {

                //ReceiveJsonMessage();
                ConnectedMessage();
                BuildNotification("Connected Success..",".......");

                checkServices=new CheckServices();
                checkServices.start();
            }
            else {
                ErrorConnectionMessage();
                BuildNotification("Error Connection..!",".......");
            }
        }
    }

    private void show(String message){

        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    // Send an Intent message

    private void ConnectingMessage() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Connecting..");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void ConnectedMessage() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Connected");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void ErrorConnectionMessage() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Error Connection..!");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void DisconnectMessage() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Disconnected Connection..!");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendDisConnectedActivity() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Disconnected");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendMessageActivity(String message) {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }


    private void sendStatusActivity(String message) {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("status", message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }


    public void BuildNotification(String title,String Content ){

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setSmallIcon(R.mipmap.ic_launcher);
        mBuilder.setContentTitle(title);
        mBuilder.setContentText(Content);


        Intent resultIntent = new Intent(this, MainActivity.class);

        // Adds the Intent that starts the Activity to the top of the stack

        PendingIntent resultPendingIntent = PendingIntent.getActivity(this, 0, resultIntent, 0);

        mBuilder.setContentIntent(resultPendingIntent);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // notificationID allows you to update the notification later on.
        mNotificationManager.notify(10, mBuilder.build());
    }


    class CheckServices extends Thread{

        int anInt = 0;
        @Override
        public void run() {
            super.run();

            while(connect) {

                anInt++;
                new Handler(Looper.getMainLooper()).post(
                        new Runnable() {
                            public void run() {
                                // yourContext is Activity or Application context

                                Toast.makeText(getApplicationContext(), "Check.." + anInt, Toast.LENGTH_SHORT).show();
                            }
                        }
                );

                ReceiveJsonMessage();

                try {

                    Thread.sleep(3000);
                } catch (Exception e) {}

            }

        }
    }

    private static void SendjsonMessage(String message){

        JSONObject object = new JSONObject();
        try {

            object.put("message", message);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            objectOutputStream.writeObject(object.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void SendjsonMessage(String key,String value){

        JSONObject object = new JSONObject();
        try {

            object.put(key, value);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            objectOutputStream.writeObject(object.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static PublicKey publicKey;

    private void ReceiveJsonMessage(){

        try {
            Object object = objectInputStream.readObject();
                JSONObject jsonObject = new JSONObject((String) object);
                if (jsonObject.has("message")) {
                    if (jsonObject.getString("message").equals("RUNNING")) {

                        //Connected Client
                        connect = true;
                        BuildNotification("Client Connected", "......");
                        ConnectedMessage();
                        SendjsonMessage("CONNECT");

                    } else if (jsonObject.getString("message").equals("STOPPING")) {

                        // Disconnect
                        connect = false;
                        BuildNotification("Error Connection", "......");
                        DisconnectMessage();
                        stopService(new Intent(getApplicationContext(), ClientConnectCall.class));
                    } else {

                        if (!jsonObject.getString("message").equals("")) {

                            //final String strToEncrypt = "My text to encrypt";
                            final String strPssword = MainActivity.KEY;
                            AES.setKey(strPssword);

                            // AES.encrypt(strToEncrypt.trim());

                            //System.out.println("String to Encrypt: " + strToEncrypt);
                            //System.out.println("Encrypted: " + AES.getEncryptedString());

                            final String strToDecrypt = jsonObject.getString("message");
                            AES.decrypt(strToDecrypt.trim());

                            System.out.println("String To Decrypt : " + strToDecrypt);
                            System.out.println("Decrypted : " + AES.getDecryptedString());

                            sendMessageActivity(AES.getDecryptedString());

                        }
                    }
                }  else if (jsonObject.has("PublicKey")) {

                    try {
                        //Object objectFromString= parseObjectFromString(jsonObject.getString("PublicKey"),PublicKey.class);
                        //System.out.println("Obj: " + objectFromString.toString() + "; type: " + objectFromString.getClass().getSimpleName());

                        byte[] publicBytes = Base64.decode(jsonObject.getString("PublicKey"),Base64.DEFAULT);
                        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
                        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                        publicKey = keyFactory.generatePublic(keySpec);

                        //And to decode the private use PKCS8EncodedKeySpec

                        System.out.println("Obj: " + publicKey.toString() + "; type: " + publicKey.getClass().getSimpleName());

                        sendStatusActivity(publicKey.toString());
                        MainActivity.Request.setEnabled(true);

                        /*publicKey=(PublicKey) new Object();
                        sendStatusActivity(publicKey.toString());
                        Editpreferences.putString("PublicKey", publicKey.toString());
                        Editpreferences.commit();*/
                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                } else if (jsonObject.has("PublicKeyPGP")) {

                    try {

                        // to read public key
                        PGPAlgorithm.SetPublicKey(jsonObject.getString("PublicKeyPGP"));

                        System.out.println("Obj: " + PGPAlgorithm.getPublicKey().toString() + "; type: " + PGPAlgorithm.getPublicKey().getClass().getSimpleName());

                        sendStatusActivity(PGPAlgorithm.getPublicKey().toString());


                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }else if (jsonObject.has("Certificate")) {

                    // Storing Certificate..
                    Editpreferences.putString("Certificate",jsonObject.getString("Certificate"));
                    Editpreferences.commit();

                    // Show Certificate..
                    sendStatusActivity(jsonObject.getString("Certificate"));
                }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {

            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    public static <T> Object parseObjectFromString(String s, Class<T> clazz) throws Exception {
        return clazz.getConstructor(new Class[] {String.class }).newInstance(s);
    }



    public static void GetPublicKey(){

        //KeyObject=true;
        SendjsonMessage("PublicKey");

    }

    public static void GetPublicKeyPGP(){

        //KeyObject=true;
        SendjsonMessage("PublicKeyPGP");

    }

    public static void Request() throws JSONException, IllegalBlockSizeException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IOException {


        JSONObject jsonObject=new JSONObject();
        jsonObject.put("name",preferences.getString("CLIENTADDRESS",""));
        jsonObject.put("agent",MainActivity.agentName.getText().toString());
        jsonObject.put("value",Integer.parseInt(MainActivity.value.getText().toString()));
        Log.d("JSONObject ..","name "+preferences.getString("CLIENTADDRESS","")+" agent "+MainActivity.agentName.getText().toString()+" value "+MainActivity.value.getText().toString());

        // Encryption..
        byte[] data=RSA_Assymetric.Encryption(jsonObject.toString(),publicKey);

        // create signature..
        GenerateDigitalSignature.main(data);

        // Supply data to sending..
        String strData=Base64.encodeToString(data,Base64.DEFAULT);
        String strSignature=Base64.encodeToString(GenerateDigitalSignature.digitalSignature,Base64.DEFAULT);
        String strPublicKey=Base64.encodeToString(GenerateDigitalSignature.publicKey.getEncoded(),Base64.DEFAULT);

        JSONObject object=new JSONObject();
        object.put("data",strData);
        object.put("signature",strSignature);
        object.put("publicKey",strPublicKey);

        //Sending..
        SendjsonMessage("Object",object.toString());

        Log.d("Object..",object.toString());

        //VerifyDigitalSignature.main(GenerateDigitalSignature.digitalSignature,Base64.decode(RSA_Assymetric.Encryption(jsonObject.toString(),publicKey),Base64.DEFAULT),GenerateDigitalSignature.publicKey);

       /* try {
            String enc=RSA_Assymetric.Encryption("hi bebe..",RSA_Assymetric.getInstance().getPublicKey());
            SealedObject sealedObject=RSA_Assymetric.decryptAnDeserializeObject(enc);
            Log.d("SealedObject..",RSA_Assymetric.getInstance().Decryption(sealedObject));
        } catch (Exception e) {
            e.printStackTrace();
        }*/

    }


    public static void RequestPGP() throws JSONException, IllegalBlockSizeException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, BadPaddingException {


        JSONObject jsonObject=new JSONObject();
        jsonObject.put("name",preferences.getString("CLIENTADDRESS",""));
        jsonObject.put("agent",MainActivity.agentName.getText().toString());
        jsonObject.put("value",Integer.parseInt(MainActivity.value.getText().toString()));
        Log.d("JSONObject ..","name "+preferences.getString("CLIENTADDRESS","")+" agent "+MainActivity.agentName.getText().toString()+" value "+MainActivity.value.getText().toString());

        // Encryption PGP..
         JSONObject object=PGPAlgorithm.Encrypt(jsonObject.toString());

        //Sending..
        SendjsonMessage("ObjectPGP",object.toString());

        Log.d("ObjectPGP..",object.toString());

        //VerifyDigitalSignature.main(GenerateDigitalSignature.digitalSignature,Base64.decode(RSA_Assymetric.Encryption(jsonObject.toString(),publicKey),Base64.DEFAULT),GenerateDigitalSignature.publicKey);

       /* try {
            String enc=RSA_Assymetric.Encryption("hi bebe..",RSA_Assymetric.getInstance().getPublicKey());
            SealedObject sealedObject=RSA_Assymetric.decryptAnDeserializeObject(enc);
            Log.d("SealedObject..",RSA_Assymetric.getInstance().Decryption(sealedObject));
        } catch (Exception e) {
            e.printStackTrace();
        }*/

    }

    public static void RequestCertificate() throws NoSuchProviderException, JSONException, NoSuchAlgorithmException, InvalidKeyException, SignatureException {

        //Make Request
        JSONObject jsonObject= CertificateRequest.Make();

        Log.d("JSON Request..",jsonObject.toString());

        //Sending..
        SendjsonMessage("CertRequest",jsonObject.toString());
        

    }



    @Override
    public void onDestroy() {
        super.onDestroy();
        Instance=null;
        connect=false;

        if(checkServices!=null){
            checkServices.interrupt();
            checkServices=null;
        }

        if(objectOutputStream!=null)
        SendjsonMessage("DISCONNECT");

        //DisconnectMessage();
        BuildNotification("Disconnected Client..!",".......");
        if(connectServer!=null) {
            connectServer.cancel(true);
            connectServer=null;
        }

        if(socket!=null){
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            socket=null;
        }

        sendDisConnectedActivity();
        stopForeground(true);
    }

}
