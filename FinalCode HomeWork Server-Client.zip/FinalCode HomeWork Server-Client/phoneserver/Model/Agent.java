package com.app.phoneserver.Model;

import android.database.Cursor;

/**
 * Created by Yehia on 11/13/2016.
 */
public class Agent {

    public String Id;
    public String Name;
    public String Password;
    public String Balance;

    public Agent(String id,String name,String password,String balance){
        this.Id=id;
        this.Name=name;
        this.Password=password;
        this.Balance=balance;
    }

    public Agent( Cursor Rows){
        this.Id=Rows.getString(Rows.getColumnIndex("Id"));
        this.Name=Rows.getString(Rows.getColumnIndex("HostName"));
        this.Password=Rows.getString(Rows.getColumnIndex("Password"));
        this.Balance=Rows.getString(Rows.getColumnIndex("Balance"));
    }

}
