package com.app.phoneserver.Activity;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.app.phoneserver.DBSQLite.DBConnections;
import com.app.phoneserver.Adapter.AdapterAgent;
import com.app.phoneserver.Model.Agent;
import com.app.phoneserver.R;
import com.app.phoneserver.Services.ServerCall;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateParsingException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class MainActivity extends AppCompatActivity {


    Button start, stop;
    TextView textView,textViewKey,status,publicKey,privateKey;
    ServerCall serverCall;
    static SharedPreferences preferences;
    SharedPreferences.Editor editor;
    private boolean bound = false;

    private ListView listView;
    private AdapterAgent adapterAgent;
    public static ArrayList<Agent> agents=new ArrayList<>();

    public static String KEY="123456";

    DBConnections dbConnections;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

       /* FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/

        preferences = this.getSharedPreferences("SERVER", MODE_PRIVATE);
        editor = this.getSharedPreferences("SERVER", this.MODE_PRIVATE).edit();

        dbConnections=new DBConnections(this);
        // Create DataBase
        if(!preferences.getBoolean("DBSQLite",false))
            CreateDBSQLite();

        textView=(TextView)findViewById(R.id.TextView);
        textViewKey=(TextView)findViewById(R.id.TextViewKey);
        status=(TextView)findViewById(R.id.status);
        publicKey=(TextView)findViewById(R.id.publicKey);
        privateKey=(TextView)findViewById(R.id.privateKey);

        textViewKey.setText("Key: "+ KEY);

        start = (Button) findViewById(R.id.ButtonStart);
        stop = (Button) findViewById(R.id.ButtonStop);



        listView=(ListView)findViewById(R.id.listview);
        agents.addAll(dbConnections.GetAllRows());
        adapterAgent=new AdapterAgent(agents,this);
        listView.setAdapter(adapterAgent);
        adapterAgent.notifyDataSetChanged();

    }

    public static String AgentRequest(String Host){

        for(Agent agent:agents){
            if(agent.Name.equals(Host))
                return agent.Balance;
        }

        return "";
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            startActivity(new Intent(MainActivity.this,Settings.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void ClickStart(View v) throws CertificateEncodingException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException, CertificateParsingException, InvalidKeySpecException {

        startService(new Intent(getApplicationContext(), ServerCall.class));

        start.setEnabled(false);
        stop.setEnabled(true);


        //DigitalCertificate.Create();
        //CertificateAuthority.getInstance(this);
        //Log.d("Query..",dbConnections.getBalance("192.168.1.5"));

    }

    public void ClickStop(View v) {


        stopService(new Intent(MainActivity.this, ServerCall.class));

        start.setEnabled(true);
        stop.setEnabled(false);


    }




    private void CreateDBSQLite(){

        // Insert Agents
        dbConnections.InsertRow("192.168.1.1","1921","2800");
        dbConnections.InsertRow("192.168.1.2","1922","2300");
        dbConnections.InsertRow("192.168.1.3","1923","15600");
        dbConnections.InsertRow("192.168.1.4","1924","19000");
        dbConnections.InsertRow("192.168.1.5","1925","3000");
        dbConnections.InsertRow("192.168.1.6","1926","12000");
        dbConnections.InsertRow("192.168.1.7","1927","16500");
        dbConnections.InsertRow("192.168.1.8","1928","29500");
        dbConnections.InsertRow("192.168.1.9","1929","6500");
        dbConnections.InsertRow("192.168.1.10","19210","9800");

        editor.putBoolean("DBSQLite",true);
        editor.commit();

    }


    public void ClickEncrypt(View v) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IOException, IllegalBlockSizeException, BadPaddingException, ClassNotFoundException {

        // AES
        /*final String strToEncrypt = "My text to encrypt";
        final String strPssword = "encryptor key";
        AES.setKey(strPssword);

        AES.encrypt(strToEncrypt.trim());

        System.out.println("String to Encrypt: " + strToEncrypt);
        System.out.println("Encrypted: " + AES.getEncryptedString());

        final String strToDecrypt =  AES.getEncryptedString();
        textView.setText(strToDecrypt);
        AES.decrypt(strToDecrypt.trim());

        System.out.println("String To Decrypt : " + strToDecrypt);
        System.out.println("Decrypted : " + AES.getDecryptedString());

        textView.setText(getIpAddr());*/

        //RSA  symm
        /*RSA rsa = new RSA(1024);

        String text1 = "Yellow and Black Border Collies";
        System.out.println("Plaintext: " + text1);
        BigInteger plaintext = new BigInteger(text1.getBytes());

        BigInteger ciphertext = rsa.encrypt(plaintext);
        System.out.println("Ciphertext: " + ciphertext);
        plaintext = rsa.decrypt(ciphertext);

        String text2 = new String(plaintext.toByteArray());
        System.out.println("Plaintext: " + text2);*/


        //RSA Asymm

        // Get an instance of the RSA key generator
        /*KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        // Generate the keys — might take sometime on slow computers
        KeyPair myPair = kpg.generateKeyPair();


        // Get an instance of the Cipher for RSA encryption/decryption
        Cipher c = Cipher.getInstance("RSA");
         // Initiate the Cipher, telling it that it is going to Encrypt, giving it the public key
        c.init(Cipher.ENCRYPT_MODE, myPair.getPublic());
        Log.d("Public... ",myPair.getPublic().toString());

        // Create a secret message
        String myMessage = new String("Secret Message");
        // Encrypt that message using a new SealedObject and the Cipher we created before
        SealedObject myEncryptedMessage= new SealedObject( myMessage, c);
        Log.d("SealedObject... ",myEncryptedMessage.toString());

        // Get an instance of the Cipher for RSA encryption/decryption
        Cipher dec = Cipher.getInstance("RSA");
        // Initiate the Cipher, telling it that it is going to Decrypt, giving it the private key
        dec.init(Cipher.DECRYPT_MODE, myPair.getPrivate());
        Log.d("Private... ",myPair.getPrivate().toString());

        // Tell the SealedObject we created before to decrypt the data and return it
        String message = (String) myEncryptedMessage.getObject(dec);
        System.out.println("foo = "+message);*/


    }

    int anInt = 10;

    public void ClickCreateNotification(View v)  {

       /* WifiManager manager = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        String ip = Formatter.formatIpAddress(manager.getConnectionInfo().getIpAddress());
        textView.setText(ip+"");*/


        textView.setText(getIpAddr()+"");


    }

    public String getIpAddr() {
        WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        int ip = wifiInfo.getIpAddress();

        String ipString = String.format(
                "%d.%d.%d.%d",
                (ip & 0xff),
                (ip >> 8 & 0xff),
                (ip >> 16 & 0xff),
                (ip >> 24 & 0xff));

        return ipString;
    }

    public String getIpAddress() {
        String ip=null;
        try {
            HttpClient httpclient = new DefaultHttpClient();
            HttpGet httpget = new HttpGet("http://ip2country.sourceforge.net/ip2c.php?format=JSON");
            // HttpGet httpget = new HttpGet("http://whatismyip.com.au/");
            // HttpGet httpget = new HttpGet("http://www.whatismyip.org/");
            HttpResponse response;

            response = httpclient.execute(httpget);
            //Log.i("externalip",response.getStatusLine().toString());

            HttpEntity entity = response.getEntity();
            entity.getContentLength();
            String str = EntityUtils.toString(entity);
            Toast.makeText(getApplicationContext(), str, Toast.LENGTH_LONG).show();
            JSONObject json_data = new JSONObject(str);
            ip = json_data.getString("ip");
            Toast.makeText(getApplicationContext(), ip, Toast.LENGTH_LONG).show();
        }
        catch (Exception e){

        }

        return ip;
    }



    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Extract data included in the Intent
            if(intent.hasExtra("message")) {
                String message = intent.getStringExtra("message");
                //Log.d("receiver", "Got message: " + message);
                if (message.equals("Disconnected")) {
                    onStop();
                    start.setEnabled(true);
                    stop.setEnabled(false);
                }else if(message.equals("UpdateView")){
                    if(agents.size()>0)
                        agents.clear();
                    agents.addAll(dbConnections.GetAllRows());
                    adapterAgent.notifyDataSetChanged();
                } else
                    textView.setText(message);

            }
            else if(intent.hasExtra("status")){
                String message = intent.getStringExtra("status");
                status.setText(message);
            }
            else if(intent.hasExtra("publicKey")){
                String message = intent.getStringExtra("publicKey");
                publicKey.setText(message);
            }
            else if(intent.hasExtra("privateKey")){
                String message = intent.getStringExtra("privateKey");
                privateKey.setText(message);
            }


        }
    };


    ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

            ServerCall.LocalBinder mLocalBinder = (ServerCall.LocalBinder)service;
            serverCall = mLocalBinder.getServerInstance();
            bound=true;
            show("Connect..");
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

            start.setEnabled(true);
            stop.setEnabled(false);
            bound=false;
            show("Disconnect..");
            serverCall=null;
        }
    };


    private void show(String message){

        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

    public void BuildNotification(){

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setSmallIcon(R.mipmap.ic_launcher);
        mBuilder.setContentTitle("Notification Alert, Click Me!");
        mBuilder.setContentText("Hi, This is Android Notification Detail!");


        Intent resultIntent = new Intent(this, MainActivity.class);

        anInt++;
        // Adds the Intent that starts the Activity to the top of the stack

        PendingIntent resultPendingIntent = PendingIntent.getActivity(this, 0, resultIntent, 0);

        mBuilder.setContentIntent(resultPendingIntent);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // notificationID allows you to update the notification later on.
        mNotificationManager.notify(anInt, mBuilder.build());
    }

    @Override
    public void onBackPressed() {

        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


    @Override
    protected void onStart() {
        super.onStart();
        // bind to Service
       /* bound=true;
        Intent intent = new Intent(this, ServerCall.class);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);*/
    }


    @Override
    protected void onResume() {
        super.onResume();

        LocalBroadcastManager.getInstance(this).registerReceiver(mMessageReceiver, new IntentFilter("Data"));

        dbConnections=new DBConnections(this);
        dbConnections.GetAllRows();

    }


    @Override
    protected void onPause() {
        // Unregister since the activity is not visible
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mMessageReceiver);
        super.onPause();
    }



    @Override
    protected void onStop() {
        super.onStop();
        // Unbind from service
        /*if (bound) {
            // unregister
            unbindService(mConnection);
            bound = false;
        }*/
    }

}
