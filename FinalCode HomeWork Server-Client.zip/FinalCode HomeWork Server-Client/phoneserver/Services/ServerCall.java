package com.app.phoneserver.Services;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Base64;
import android.util.Log;
import android.widget.Toast;

import com.app.phoneserver.DBSQLite.DBConnections;
import com.app.phoneserver.Security.DigitalSignature.VerifyDigitalSignature;
import com.app.phoneserver.Activity.MainActivity;
import com.app.phoneserver.R;
import com.app.phoneserver.Security.PGPAlgorithm;
import com.app.phoneserver.Security.RSA;
import com.app.phoneserver.Security.Server.CertificateAuthority;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.NoSuchPaddingException;
import javax.crypto.SealedObject;

/**
 * Created by Yehia on 7/25/2016.
 */
public class ServerCall extends Service {

    public static ServerCall Instance=null;
    task run;
    static boolean connect=false;
    //ConnectServer connectServer;
    private Socket socket;
    private  ServerSocket serverSocket;
    private DataOutputStream outputStream;
    private BufferedReader inputStream;
    ObjectInputStream objectInputStream ;
    ObjectOutputStream objectOutputStream ;
    private final IBinder mBinder = new LocalBinder();
    static Activity activity;
    static SharedPreferences preferences;
    private static int Port=8888;

    private static boolean status = false;




    public static ServerCall initial(){
        return Instance;
    }

    public static boolean CheckService(){

        return Instance!=null;
    }

    public static boolean isCalling(){
        return status;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    public class LocalBinder extends Binder {
        public ServerCall getServerInstance() {
            return ServerCall.this;
        }
    }
    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(R.string.app_name, new Notification());
        Instance=this;

        //show(Integer.toString(minBufSize));

        //connectServer=new ConnectServer();
        run=new task();
        preferences = this.getSharedPreferences("SERVICES", MODE_PRIVATE);
        Port = preferences.getInt("PORT", 8888);

        // SettingUp CA Server
        try {
            CertificateAuthority.getInstance(getApplicationContext());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (InvalidKeySpecException e) {
            e.printStackTrace();
        }

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        connect=true;
        run.start();
        //connectServer.execute();

        show("start service..");
        return ServerCall.START_STICKY;
    }




    private void show(String message){

        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }


    class task extends Thread{

        int anInt = 0;
        @Override
        public void run() {
            super.run();

            //Looper.prepare();
            while(connect) {

                anInt++;
                new Handler(Looper.getMainLooper()).post(
                        new Runnable() {
                            public void run() {
                                // yourContext is Activity or Application context

                                Toast.makeText(getApplicationContext(), "Check.." + anInt, Toast.LENGTH_SHORT).show();
                            }
                        }
                );

                if(socket==null & serverSocket==null) {
                    //CreateNewServer();
                    //Creating
                    new create().start();
                    BuildNotification("Creating Server", "......");
                    sendCreateMessage();
                }
                else if(socket==null & serverSocket!=null)
                {
                    //Creating Successfuly
                    //Waiting
                    BuildNotification("Waiting For Client", "......");
                    sendWaitingMessage();
                }
                else if(socket.isConnected()) {

                    //socket!=null

                    SendjsonMessage("RUNNING");
                    try {
                        try {
                            ReceiveJsonMessage();
                        } catch (NoSuchPaddingException e) {
                            e.printStackTrace();
                        } catch (CertificateEncodingException e) {
                            e.printStackTrace();
                        } catch (InvalidKeyException e) {
                            e.printStackTrace();
                        } catch (SignatureException e) {
                            e.printStackTrace();
                        } catch (CertificateParsingException e) {
                            e.printStackTrace();
                        } catch (NoSuchProviderException e) {
                            e.printStackTrace();
                        } catch (InvalidKeySpecException e) {
                            e.printStackTrace();
                        }
                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    }

                }


                try {

                    Thread.sleep(3000);
                } catch (Exception e) {}

            }

        }

    }

    private void SendjsonMessage(String message){

        JSONObject object = new JSONObject();
        try {

            object.put("message", message);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            objectOutputStream.writeObject(object.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void SendjsonMessage(String key,String value){


            JSONObject object = new JSONObject();
            try {

                object.put(key, value);

            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                objectOutputStream.writeObject(object.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }

    }

    private void ReceiveJsonMessage() throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, CertificateEncodingException, NoSuchProviderException, CertificateParsingException, InvalidKeyException, SignatureException {

        try {
            Object object = objectInputStream.readObject();
                JSONObject jsonObject = new JSONObject((String) object);
                if (jsonObject.has("message")) {
                    if (jsonObject.getString("message").equals("CONNECT")) {

                        //Connected Client
                        connect = true;
                        BuildNotification("Client Connected", "......");
                        sendConnectMessage();

                    } else if (jsonObject.getString("message").equals("DISCONNECT")) {

                        // Disconnect
                        connect = false;
                        BuildNotification("Disconnect", "......");
                        sendDisConnectedMessage();
                        stopService(new Intent(getApplicationContext(), ServerCall.class));
                    } else if (jsonObject.getString("message").equals("PublicKey")) {

                        //KeyObject=true;
                        // Create Public Key
                        sendStatusActivity("Creating Public&Private Key..");

                        sendPublicKeyActivity("Public Key:" + RSA.getInstance().getPublicKey());
                        sendPrivateKeyActivity("Private Key:" + RSA.getInstance().getPrivateKey());

                        sendStatusActivity("Success Created Public&Private Key ..");

                        SendjsonMessage("PublicKey", Base64.encodeToString(RSA.getInstance().getPublicKey().getEncoded(),Base64.DEFAULT));
                        //SendjsonMessage("PublicKey",new Integer("123").toString());

                        Log.d("Public Key ... ", RSA.getInstance().getPublicKey().toString());

                    } else if (jsonObject.getString("message").equals("PublicKeyPGP")) {


                        // Create Public Key
                        sendStatusActivity("Creating Public&Private Key..");

                        sendPublicKeyActivity("Public Key:" + PGPAlgorithm.getInstance().getPublicKey());
                        sendPrivateKeyActivity("Private Key:" + PGPAlgorithm.getInstance().getPrivateKey());

                        sendStatusActivity("Success Created Public&Private Key ..");

                        SendjsonMessage("PublicKeyPGP", Base64.encodeToString(PGPAlgorithm.getInstance().getPublicKey().getEncoded(),Base64.DEFAULT));
                        //SendjsonMessage("PublicKey",new Integer("123").toString());

                        Log.d("PublicKeyPGP... ", RSA.getInstance().getPublicKey().toString());

                    }else {

                        // AES
                   /*if( !MainActivity.AgentRequest(jsonObject.getString("message")).equals("")) {
                       final String strToEncrypt = MainActivity.AgentRequest(jsonObject.getString("message"));
                       final String strPssword = MainActivity.KEY;
                       AES.setKey(strPssword);

                       AES.encrypt(strToEncrypt.trim());

                       System.out.println("String to Encrypt: " + strToEncrypt);
                       System.out.println("Encrypted: " + AES.getEncryptedString());

                       final String strToDecrypt = AES.getEncryptedString();
                       //textView.setText(strToDecrypt);
                       SendjsonMessage(strToDecrypt);

                       sendMessageActivity(strToDecrypt);

                       AES.decrypt(strToDecrypt.trim());

                       System.out.println("String To Decrypt : " + strToDecrypt);
                       System.out.println("Decrypted : " + AES.getDecryptedString());
                   }*/


                    }
                } else if(jsonObject.has("Object")){

                    try {

                        // Receiving DataEncryption , Signature ,PublicKey
                        JSONObject object1=new JSONObject(jsonObject.getString("Object"));
                        String strData=object1.getString("data");
                        String strSignature=object1.getString("signature");
                        String strPublicKey=object1.getString("publicKey");

                        Log.d("Object..",object1.toString());

                        // Creating Variables
                        byte[] data=Base64.decode(strData,Base64.DEFAULT);
                        byte[] signature=Base64.decode(strSignature,Base64.DEFAULT);
                        byte[] publicKeyDecoded=Base64.decode(strPublicKey,Base64.DEFAULT);

                        // Verification..
                        if(VerifyDigitalSignature.main(signature,data,publicKeyDecoded))
                        {
                            // get SealedObject from byte[] ..
                            SealedObject sealedObject= RSA.decryptAnDeserializeObject(data);

                            //Decryption with private Key..
                            JSONObject json=new JSONObject(RSA.getInstance().Decryption(sealedObject));
                            Log.d("JSONObject..",json.toString());

                            // Apply Transaction DataBase..
                            DBConnections dbConnections=new DBConnections(this);
                            dbConnections.ApplyTransaction(json.getString("name"),json.getString("agent"),json.getString("value"),strSignature);

                            sendStatusActivity("Success Data verified..");
                            sendMessageActivity("UpdateView");

                        }else{
                            sendStatusActivity("Cannot verify data..");
                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }else if(jsonObject.has("ObjectPGP")){

                    try {

                        // Receiving DataEncryption , SecretKey
                        //Decryption with private Key..
                       String data=PGPAlgorithm.Decryption(new JSONObject(jsonObject.getString("ObjectPGP")));

                        Log.d("ObjectPGP..",jsonObject.getString("ObjectPGP"));


                            JSONObject json=new JSONObject(data);
                            Log.d("JSONObject..",json.toString());

                            // Apply Transaction DataBase..
                            DBConnections dbConnections=new DBConnections(this);
                            dbConnections.ApplyTransaction(json.getString("name"),json.getString("agent"),json.getString("value")," ");

                            sendStatusActivity("Success Transaction..");
                            sendMessageActivity("UpdateView");



                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }else if(jsonObject.has("CertRequest")){

                    // Getting Request Info
                    JSONObject Request=new JSONObject(jsonObject.getString("CertRequest"));

                    // SettingUp Info Object
                    byte [] data=Base64.decode(Request.getString("data"),Base64.DEFAULT);
                    byte [] signature=Base64.decode(Request.getString("signature"),Base64.DEFAULT);
                    byte [] publicKeyEncoding=Base64.decode(Request.getString("publicKey"),Base64.DEFAULT);

                    // Verifing Request..
                    sendStatusActivity("Verifing Request..");
                    if(CertificateAuthority.VerifingRequest(signature,data,publicKeyEncoding));
                    {
                        // Making Public key Object..
                        X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyEncoding);
                        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                        PublicKey publicKeyClient = keyFactory.generatePublic(publicKeySpec);
                        sendStatusActivity("Generatting Certificate..");

                        // Generatting Certificate..
                        X509Certificate certificate= CertificateAuthority.GenerateCertificate(publicKeyClient);
                        sendStatusActivity("Success Generate Certificate..");

                        // Sending Certificate..
                        SendjsonMessage("Certificate",certificate.toString());

                    }

                }


        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }


    class create extends Thread{
        @Override
        public void run() {
            super.run();
            try {
                try {
                    CreateNewServer();
                } catch (NoSuchPaddingException e) {
                    e.printStackTrace();
                } catch (CertificateEncodingException e) {
                    e.printStackTrace();
                } catch (InvalidKeyException e) {
                    e.printStackTrace();
                } catch (SignatureException e) {
                    e.printStackTrace();
                } catch (CertificateParsingException e) {
                    e.printStackTrace();
                } catch (NoSuchProviderException e) {
                    e.printStackTrace();
                } catch (InvalidKeySpecException e) {
                    e.printStackTrace();
                }
            } catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            }
        }
    }

    private void CreateNewServer() throws NoSuchAlgorithmException, NoSuchPaddingException, CertificateParsingException, CertificateEncodingException, SignatureException, NoSuchProviderException, InvalidKeyException, InvalidKeySpecException {

        try {
            serverSocket = new ServerSocket(Port) ;
            Log.e("pooooooort",Port+"");

            //log("Waiting for client...");
            socket = serverSocket.accept();
            outputStream = new DataOutputStream(socket.getOutputStream());
            inputStream = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            objectOutputStream= new ObjectOutputStream(outputStream);
            objectInputStream= new ObjectInputStream(socket.getInputStream());
            connect=true;
            //DeviceName += "2";
            //log("a new client Connected");

        } catch (IOException e) {

        }

    }

   /* private String  getLocalIp(){
        WifiManager manager = (WifiManager) getSystemService(Context.WIFI_SERVICE);

    }*/

    // Send an Intent message

    private void sendCreateMessage() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Creating Server..");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendWaitingMessage() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Waiting For Client..");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendConnectMessage() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Client Connected Success.."+"\n"+"Your Server Host: ");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendDisConnectedMessage() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Disconnected Client..!");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendDisConnectedActivity() {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", "Disconnected");
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendStatusActivity(String message) {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("status", message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendPublicKeyActivity(String message) {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("publicKey", message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }


    private void sendPrivateKeyActivity(String message) {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("privateKey", message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private void sendMessageActivity(String message) {
        Intent intent = new Intent("Data");
        // add data
        intent.putExtra("message", message);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }


    public void BuildNotification(String title,String Content ){

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(this);
        mBuilder.setSmallIcon(R.mipmap.ic_launcher);
        mBuilder.setContentTitle(title);
        mBuilder.setContentText(Content);


        Intent resultIntent = new Intent(this, MainActivity.class);

        // Adds the Intent that starts the Activity to the top of the stack

        PendingIntent resultPendingIntent = PendingIntent.getActivity(this, 0, resultIntent, 0);

        mBuilder.setContentIntent(resultPendingIntent);

        NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // notificationID allows you to update the notification later on.
        mNotificationManager.notify(10, mBuilder.build());
    }




    @Override
    public void onDestroy() {
        super.onDestroy();
        Instance=null;
        connect=false;

        if(objectOutputStream!=null)
        SendjsonMessage("STOPPING");

        if(run!=null) {
            run.interrupt();
            run=null;

        }
        if(serverSocket!=null){

            try {
                serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            serverSocket=null;
        }


        if(socket!=null){
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            socket=null;
        }


        sendDisConnectedActivity();
        stopForeground(true);
        show("stop service..");
    }


}
