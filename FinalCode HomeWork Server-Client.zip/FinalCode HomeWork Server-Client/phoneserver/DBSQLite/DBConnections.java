package com.app.phoneserver.DBSQLite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.app.phoneserver.Model.Agent;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

/**
 * Created by Yehia on 11/30/2016.
 */

public class DBConnections extends SQLiteOpenHelper {

    public static final String DBName="Server.db";
    public static final int Version=1;

    public DBConnections(Context context) {
        super(context, DBName, null, Version);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("CREATE TABLE `Agents` (\n" +
                "\t`Id`\tINTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,\n" +
                "\t`HostName`\tTEXT NOT NULL,\n" +
                "\t`Password`\tTEXT NOT NULL,\n" +
                "\t`Balance`\tINTEGER NOT NULL\n" +
                ")");

        Log.d("DataBase Create..","Agents");

        sqLiteDatabase.execSQL("CREATE TABLE `Transaction` (\n" +
                "\t`Id`\tINTEGER NOT NULL PRIMARY KEY AUTOINCREMENT UNIQUE,\n" +
                "\t`HostName`\tTEXT NOT NULL,\n" +
                "\t`ToAgentName`\tTEXT NOT NULL,\n" +
                "\t`Value`\tTEXT NOT NULL,\n" +
                "\t`Date`\tTEXT NOT NULL,\n" +
                "\t`Signature`\tTEXT NOT NULL\n" +
                ")");

        Log.d("DataBase Create..","Transaction");
        //Log.d("DataBase..","Create..");

    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS `Agents`");
        onCreate(sqLiteDatabase);
        Log.d("DataBase..","Upgrade..");
    }

    public void UpdateDecrementRow(String hostName,String balance){

        int currentBalance=Integer.parseInt(getBalance(hostName));
        currentBalance-=Integer.parseInt(balance);
        UpdateRowBalance(hostName,String.valueOf(currentBalance));
    }

    public void UpdateIncrementRow(String agentName,String balance ){

        int currentBalance=Integer.parseInt(getBalance(agentName));
        currentBalance+=Integer.parseInt(balance);
        UpdateRowBalance(agentName,String.valueOf(currentBalance));
    }



    public void UpdateRowBalance(String name,String balance){
        SQLiteDatabase database=this.getWritableDatabase();
        database.execSQL("UPDATE `Agents` SET `Balance`="+balance+" WHERE `HostName`=\""+name+"\"");
        database.close();
    }

    public String getBalance(String name){

        SQLiteDatabase database=this.getReadableDatabase();
        Cursor Rows=database.rawQuery("select A.Balance from Agents as A where A.HostName=\""+name+"\"",null);
        Rows.moveToFirst();
        database.close();
        return Rows.getString(Rows.getColumnIndex("Balance"));
    }

    public void InsertRow(String name,String password,String balance){
        SQLiteDatabase database=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("HostName",name);
        contentValues.put("Password",password);
        contentValues.put("Balance",balance);
        database.insert("Agents",null,contentValues);
        database.close();
    }

    public ArrayList<Agent> GetAllRows(){
        SQLiteDatabase database=this.getReadableDatabase();
        ArrayList<Agent> arrayList=new ArrayList<Agent>();
        Cursor Rows=database.rawQuery("SELECT * FROM `Agents`",null);
        Rows.moveToFirst();
        while(Rows.isAfterLast()==false){
            arrayList.add(new Agent(Rows));
            //Log.d("Row..",Rows.getString(Rows.getColumnIndex("Id"))+" "+Rows.getString(Rows.getColumnIndex("HostName"))+" "+Rows.getString(Rows.getColumnIndex("Balance")));

            Rows.moveToNext();
        }

        database.close();
        return arrayList;
    }

    public void getAllTransaction(){

        SQLiteDatabase database=this.getReadableDatabase();
        Cursor Rows=database.rawQuery("SELECT * FROM `Transaction`",null);
        Rows.moveToFirst();
        while(Rows.isAfterLast()==false){

            Log.d("Row..",Rows.getString(Rows.getColumnIndex("Id"))+" "+Rows.getString(Rows.getColumnIndex("HostName"))+" "+Rows.getString(Rows.getColumnIndex("Value"))+" "+Rows.getString(Rows.getColumnIndex("Date")));

            Rows.moveToNext();
        }

        database.close();
    }

    public void AddTransactionRow(String hostName,String toAgentName,String value,String date,String Signature){

        SQLiteDatabase database=this.getWritableDatabase();
        database.execSQL("INSERT INTO `Transaction`(`HostName`,`ToAgentName`,`Value`,`Date`,`Signature`) VALUES ('"+hostName+"','"+toAgentName+"','"+value+"','"+date+"','"+Signature+"')");
        database.close();
    }

    public void ApplyTransaction(String hostName,String toAgentName,String value,String Signature){

        // Decrement..
        UpdateDecrementRow(hostName,value);

        //Increment..
        UpdateIncrementRow(toAgentName,value);

        //get Date System..
        final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
        Calendar time= Calendar.getInstance();
        Log.d("System time..",dateFormat.format(time.getTime()));

        // Add Row To Transaction Table..
        AddTransactionRow(hostName,toAgentName,value,Signature,dateFormat.format(time.getTime()));

        //Print Transaction..
        getAllTransaction();

    }

}
