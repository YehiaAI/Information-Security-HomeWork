package com.app.phoneserver.Security.Server;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import android.util.Log;

import com.app.phoneserver.Security.DigitalCertificate;
import com.app.phoneserver.Security.DigitalSignature.VerifyDigitalSignature;

import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

/**
 * Created by Yehia on 12/16/2016.
 */

public class CertificateAuthority {

    private static CertificateAuthority Instance=null;
    private static Context context;
    private static PrivateKey privateKey;
    private static PublicKey publicKey;
    static SharedPreferences preferences;
    static SharedPreferences.Editor editor;


    public static CertificateAuthority getInstance(Context mainContext) throws NoSuchAlgorithmException, InvalidKeySpecException {

        context=mainContext;
        preferences = context.getSharedPreferences("CA", context.MODE_PRIVATE);
        editor = context.getSharedPreferences("CA", context.MODE_PRIVATE).edit();

        if(Instance==null)
            Instance=new CertificateAuthority();
        return Instance;
    }

    private CertificateAuthority() throws NoSuchAlgorithmException, InvalidKeySpecException {

        if(!preferences.getBoolean("GenerateKey",false)){

            GenerateKey();
        }else
            getInstanceKey();
    }

    private void GenerateKey() throws NoSuchAlgorithmException {

        // Get an instance of the RSA key generator
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        // Generate the keys — might take sometime on slow computers
        KeyPair keyPair= kpg.generateKeyPair();
        privateKey=keyPair.getPrivate();
        publicKey=keyPair.getPublic();
        editor.putString("PublicKey", Base64.encodeToString(publicKey.getEncoded(),Base64.DEFAULT));
        editor.putString("PrivateKey",Base64.encodeToString(privateKey.getEncoded(),Base64.DEFAULT));
        editor.putBoolean("GenerateKey",true);
        editor.commit();
        Log.d("Generate CA Public..",publicKey.toString());
        Log.d("Generate CA Private..",privateKey.toString());
    }

    private void getInstanceKey() throws NoSuchAlgorithmException, InvalidKeySpecException {

        // get Publickey
        byte[] publicBytes = Base64.decode(preferences.getString("PublicKey",null),Base64.DEFAULT);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        publicKey = keyFactory.generatePublic(keySpec);
        Log.d("Get CA Public..",publicKey.toString());

        // get PrivateKey
        byte[] privateBytes = Base64.decode(preferences.getString("PrivateKey",null),Base64.DEFAULT);
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(privateBytes);
        KeyFactory factory = KeyFactory.getInstance("RSA");
        privateKey = factory.generatePrivate(pkcs8EncodedKeySpec);
        Log.d("Get CA Private..",privateKey.toString());

    }

    public static boolean VerifingRequest(byte[] digitalSignature,byte[] data,byte[] publicKeyEncoded){

        return VerifyDigitalSignature.main(digitalSignature,data,publicKeyEncoded);
    }


    public static X509Certificate GenerateCertificate(PublicKey publicKeyClient) throws NoSuchAlgorithmException, CertificateEncodingException, NoSuchProviderException, SignatureException, CertificateParsingException, InvalidKeyException {


        return DigitalCertificate.Create(publicKeyClient,publicKey,privateKey);
    }

}
