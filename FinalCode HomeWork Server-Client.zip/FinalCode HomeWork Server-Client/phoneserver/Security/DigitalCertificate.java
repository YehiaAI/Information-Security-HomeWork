package com.app.phoneserver.Security;

import android.util.Log;

import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.x509.Attribute;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.X509Extension;
import org.bouncycastle.asn1.x509.X509Extensions;
import org.bouncycastle.asn1.x509.X509Name;
import org.bouncycastle.jce.PKCS10CertificationRequest;
import org.bouncycastle.jce.X509Principal;
import org.bouncycastle.x509.X509V1CertificateGenerator;
import org.bouncycastle.x509.X509V3CertificateGenerator;
import org.bouncycastle.x509.extension.AuthorityKeyIdentifierStructure;
import org.bouncycastle.x509.extension.SubjectKeyIdentifierStructure;

import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SignatureException;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

import javax.security.auth.x500.X500Principal;

/**
 * Created by Yehia on 12/16/2016.
 */


public class DigitalCertificate {

    //Version 1 Certificate Creation
    /*public static void Create() throws NoSuchAlgorithmException, CertificateEncodingException, NoSuchProviderException, InvalidKeyException, SignatureException {
        Date startDate =new Date();              // time from which certificate is valid
        Date expiryDate =new Date();             // time after which certificate is not valid
        BigInteger serialNumber =new BigInteger("123456");
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");// serial number for certificate
        KeyPair keyPair =kpg.generateKeyPair();             // EC public/private key pair
        X509V1CertificateGenerator certGen = new X509V1CertificateGenerator();
        X500Principal dnName = new X500Principal("CN=Test CA Certificate");
        certGen.setSerialNumber(serialNumber);
        certGen.setIssuerDN(dnName);
        certGen.setNotBefore(startDate);
        certGen.setNotAfter(expiryDate);
        certGen.setSubjectDN(dnName);                       // note: same as issuer
        certGen.setPublicKey(keyPair.getPublic());
        certGen.setSignatureAlgorithm("SHA512withRSA");
        X509Certificate cert = certGen.generate(keyPair.getPrivate(), "BC");
        Log.d("Certificate",cert.toString());
    }*/


    public static void Create() throws CertificateParsingException, InvalidKeyException, NoSuchAlgorithmException, CertificateEncodingException, NoSuchProviderException, SignatureException {

        Date startDate = new Date();                // time from which certificate is valid
        Date expiryDate = new Date();               // time after which certificate is not valid
        expiryDate.setYear(startDate.getYear()+2);
        BigInteger serialNumber = new BigInteger(100,new Random());       // serial number for certificate
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");// serial number for certificate
        KeyPair Pair =kpg.generateKeyPair();             // EC public/private key pair
        PrivateKey caKey = Pair.getPrivate();              // private key of the certifying authority (ca) certificate
        //X509Certificate caCert = ;        // public key certificate of the certifying authority
        KeyPair keyPair =kpg.generateKeyPair();               // public/private key pair that we are creating certificate for
        X509V3CertificateGenerator certGen = new X509V3CertificateGenerator();
        X500Principal              IssuerName = new X500Principal("CN=CA C=Syria L=Damascus IP=192.168.1.1");
        X500Principal              subjectName = new X500Principal("CN=CA");
        //X509Name x509Name=new X509Name("CN=CA");

        certGen.setSerialNumber(serialNumber);
        certGen.setIssuerDN(IssuerName);
        certGen.setNotBefore(startDate);
        certGen.setNotAfter(expiryDate);
        certGen.setSubjectDN(subjectName);
        certGen.setPublicKey(keyPair.getPublic());
        certGen.setSignatureAlgorithm("SHA1withRSA");

        certGen.addExtension(X509Extensions.AuthorityKeyIdentifier, false, new AuthorityKeyIdentifierStructure(Pair.getPublic()));
        certGen.addExtension(X509Extensions.SubjectKeyIdentifier, false, new SubjectKeyIdentifierStructure(keyPair.getPublic()));

        X509Certificate cert = certGen.generate(caKey);   // note: private key of CA
        Log.d("Certificate",cert.toString());

        /*try {
            cert.verify(Pair.getPublic());
        } catch (CertificateException e) {
            e.printStackTrace();

        }catch (InvalidKeyException e) {
            e.printStackTrace();
            Log.d("Error","Not Verifing2..");
        }*/

        Log.d("Public CA",Pair.getPublic().toString());
        Log.d("Public Client",keyPair.getPublic().toString());

    }

    public static void Request() throws NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException, SignatureException {

        // create the extension value
        GeneralNames subjectAltName = new GeneralNames(new GeneralName(GeneralName.rfc822Name, "example@example.org"));


         // create the extensions object and add it as an attribute
        Vector oids = new Vector();
        Vector values = new Vector();

        oids.add(X509Extensions.SubjectAlternativeName);
        values.add(new X509Extension(false, new DEROctetString(subjectAltName)));

        X509Extensions extensions = new X509Extensions(oids, values);
        Attribute attribute = new Attribute(
                PKCSObjectIdentifiers.pkcs_9_at_extensionRequest,
                new DERSet(extensions));

        X500Principal subjectName = new X500Principal("CN=Test V3 Certificate");

        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");        // serial number for certificate
        KeyPair keyPair =kpg.generateKeyPair();                            // EC public/private key pair



        PKCS10CertificationRequest kpGen = new PKCS10CertificationRequest("SHA512withRSA",subjectName , keyPair.getPublic(),new DERSet(attribute) ,keyPair.getPrivate());

        Log.d("RequestCA..",kpGen.getCertificationRequestInfo().getAttributes().toString());
    }

    public static X509Certificate  Create(PublicKey publicKeyClient,PublicKey publicKeyCA,PrivateKey privateKeyCA) throws CertificateParsingException, InvalidKeyException, NoSuchAlgorithmException, CertificateEncodingException, NoSuchProviderException, SignatureException {

        Date startDate = new Date();                                      // time from which certificate is valid
        Date expiryDate = new Date();                                     // time after which certificate is not valid
        expiryDate.setYear(startDate.getYear()+2);
        BigInteger serialNumber = new BigInteger(100,new Random());       // serial number for certificate
        // privateKeyCA                                                  // private key of the certifying authority (ca) certificate
        // publicKeyCA                                                     // public key certificate of the certifying authority
        // publicKeyClient                                              // public key that we are creating certificate for
        X509V3CertificateGenerator certGen = new X509V3CertificateGenerator();
        X500Principal              IssuerName = new X500Principal("CN=Test V3 Certificate");
        X500Principal              subjectName = new X500Principal("CN=Test V3 Certificate");
        //X509Name x509Name=new X509Name("CA");

        certGen.setSerialNumber(serialNumber);
        certGen.setIssuerDN(IssuerName);
        certGen.setNotBefore(startDate);
        certGen.setNotAfter(expiryDate);
        certGen.setSubjectDN(subjectName);
        certGen.setPublicKey(publicKeyClient);
        certGen.setSignatureAlgorithm("SHA1withRSA");

        certGen.addExtension(X509Extensions.AuthorityKeyIdentifier, false, new AuthorityKeyIdentifierStructure(publicKeyCA));
        certGen.addExtension(X509Extensions.SubjectKeyIdentifier, false, new SubjectKeyIdentifierStructure(publicKeyClient));

        X509Certificate cert = certGen.generate(privateKeyCA);   // note: private key of CA
        Log.d("Certificate",cert.toString());

        /*try {
            cert.verify(Pair.getPublic());
        } catch (CertificateException e) {
            e.printStackTrace();

        }catch (InvalidKeyException e) {
            e.printStackTrace();
            Log.d("Error","Not Verifing2..");
        }*/

        Log.d("Public CA",publicKeyCA.toString());

        Log.d("Public Client",publicKeyClient.toString());
        return cert;
    }


}
