package com.app.phoneserver.Security.DigitalSignature;

/**
 * Created by Yehia on 12/3/2016.
 */

import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;

public class VerifyDigitalSignature {
    public static boolean main(byte[] digitalSignature,byte[] data,byte[] publicKeyEncoded) {
        boolean verified=false;

        try {
            //byte[] publicKeyEncoded = Files.readAllBytes(Paths.get("publickey"));
            //byte[] digitalSignature = Files.readAllBytes(Paths.get("signature"));

            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyEncoded);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");

            PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
            Signature signature = Signature.getInstance("SHA1withRSA");
            signature.initVerify(publicKey);

            //byte[] bytes = Files.readAllBytes(Paths.get("README"));
            signature.update(data);

             verified = signature.verify(digitalSignature);
            if (verified) {
                System.out.println("Data verified..");

                return verified;
            } else {
                System.out.println("Cannot verify data..");

                return verified;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  verified;
    }
}
