package com.app.phoneserver.Fragment;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.MultiSelectListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceGroup;
import android.preference.PreferenceManager;

import com.app.phoneserver.R;

import java.util.Set;

/**
 * Created by Yehia on 6/29/2016.
 */
public class SettingFragment extends PreferenceFragment implements
        SharedPreferences.OnSharedPreferenceChangeListener {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        addPreferencesFromResource(R.xml.setting);

        PreferenceManager.setDefaultValues(getActivity().getApplicationContext(), R.xml.setting, false);
        initSummary(getPreferenceScreen());
    }

    @Override
    public void onResume() {
        super.onResume();
        // Set up a listener whenever a key changes
        getPreferenceScreen().getSharedPreferences()
                .registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        // Unregister the listener whenever a key changes
        getPreferenceScreen().getSharedPreferences()
                .unregisterOnSharedPreferenceChangeListener(this);
    }

    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences,
                                          String key) {
        updatePrefSummary(findPreference(key));
    }

    private void initSummary(Preference p) {
        if (p instanceof PreferenceGroup) {
            PreferenceGroup pGrp = (PreferenceGroup) p;
            for (int i = 0; i < pGrp.getPreferenceCount(); i++) {
                initSummary(pGrp.getPreference(i));
            }
        } else {
            updatePrefSummary(p);
        }
    }

    private void updatePrefSummary(Preference p) {

        if (p instanceof ListPreference) {
            ListPreference listPref = (ListPreference) p;
            p.setSummary(listPref.getEntry());
        }

        if (p instanceof CheckBoxPreference) {
            CheckBoxPreference checkBoxPreference = (CheckBoxPreference) p;

            //System.out.println("state pref " + checkBoxPreference.isChecked());

           /* if(checkBoxPreference.getTitle().equals("Auto Turn on App (Android System)")){


                try {
                    SharedPreferences.Editor editor = getActivity().getSharedPreferences(
                            "Data", getActivity().MODE_PRIVATE).edit();
                    editor.putBoolean("STARTBOOT",checkBoxPreference.isChecked());
                    editor.commit();
                }catch(Exception e){}
            }*/




        }

        if (p instanceof EditTextPreference) {
            EditTextPreference editTextPref = (EditTextPreference) p;

            p.setSummary(editTextPref.getText());


             if(p.getTitle().toString().equals("Port"))
            {

                // To Save Port Name

                try {

                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("SERVICES", getActivity().MODE_PRIVATE).edit();
                    editor.putInt("PORT", Integer.parseInt(editTextPref.getText().toString()));
                    editor.commit();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            if(p.getTitle().toString().equals("Client Address"))
            {

                // To Save Client Address

                try {

                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("SERVICES", getActivity().MODE_PRIVATE).edit();
                    editor.putString("CLIENT", editTextPref.getText().toString());
                    editor.commit();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

        }


        if (p instanceof MultiSelectListPreference) {
            MultiSelectListPreference multiSelectPref = (MultiSelectListPreference) p;

            String summary = "";

            CharSequence[] entries = multiSelectPref.getEntries();
            Set<String> selectedValues = multiSelectPref.getValues();

            for (String value : selectedValues) {
                summary += entries[multiSelectPref.findIndexOfValue(value)] + ", ";
            }

            p.setSummary(summary);
        }
    }


}
