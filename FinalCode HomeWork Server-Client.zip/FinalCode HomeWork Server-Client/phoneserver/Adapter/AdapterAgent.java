package com.app.phoneserver.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.app.phoneserver.Model.Agent;
import com.app.phoneserver.R;

import java.util.ArrayList;

/**
 * Created by Yehia on 11/13/2016.
 */

public class AdapterAgent extends BaseAdapter {

    Activity activity;
    public ArrayList<Agent> items = new ArrayList<>();


    public AdapterAgent(ArrayList<Agent> item,Activity context) {

        items = item;
        activity=context;
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {


        View view;

        LayoutInflater inflater = activity.getLayoutInflater();
        view = inflater.inflate(R.layout.list_item, null);

        TextView Host= (TextView) view.findViewById(R.id.Host);
        TextView Balance= (TextView) view.findViewById(R.id. Price);

        Host.setText(items.get(position).Name);
        Balance.setText(items.get(position).Balance);



        return view;
    }

}
